#ifndef MENU_H
#define MENU_H
#pragma once

#include "support.h"
#include "button.h"
#include "buttonSearch.h"
class Menu
{
public:
	Menu();
	~Menu();

};
#endif
