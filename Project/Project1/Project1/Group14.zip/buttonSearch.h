#ifndef BUTTONSEARCH_H
#define BUTTONSEARCH_H
#include<iostream>
#pragma once
#include "button.h"
using namespace std;

class buttonSearch {
public:
	buttonSearch();

	~buttonSearch();

};
#endif
